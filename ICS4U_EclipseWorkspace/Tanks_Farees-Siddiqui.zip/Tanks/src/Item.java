
public class Item {
	
	private int weight;
	private String name;
	
	Item(int _weight, String _name){
		weight = _weight;
		name = _name;
		
	}
	
	public String getName() {
		return name;
	}
	
	public int getWeight() {
		return weight;
	}
	
	
}
